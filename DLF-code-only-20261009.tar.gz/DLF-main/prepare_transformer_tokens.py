"""Retokenize processed multimodal data for a Hugging Face text encoder."""

import argparse
import pickle
from pathlib import Path

import numpy as np
from transformers import AutoTokenizer


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--input",
        type=Path,
        default=Path("dataset/MOSI/Processed/aligned_50.pkl"),
    )
    parser.add_argument(
        "--output",
        type=Path,
        default=Path("dataset/MOSI/Processed/aligned_50_deberta_v3.pkl"),
    )
    parser.add_argument("--pretrained", default="microsoft/deberta-v3-base")
    parser.add_argument("--max-length", type=int, default=50)
    return parser.parse_args()


def tokenize_split(tokenizer, raw_text, max_length):
    encoded = tokenizer(
        [str(text) for text in raw_text],
        padding="max_length",
        truncation=True,
        max_length=max_length,
        return_tensors="np",
    )
    input_ids = encoded["input_ids"].astype(np.int64)
    attention_mask = encoded["attention_mask"].astype(np.int64)
    token_type_ids = encoded.get("token_type_ids")
    if token_type_ids is None:
        token_type_ids = np.zeros_like(input_ids)
    else:
        token_type_ids = token_type_ids.astype(np.int64)
    return np.stack((input_ids, attention_mask, token_type_ids), axis=1)


def main():
    args = parse_args()
    if args.max_length <= 0:
        raise ValueError("--max-length must be positive")
    if args.input.resolve() == args.output.resolve():
        raise ValueError("Input and output must differ to preserve the source tokens")

    tokenizer = AutoTokenizer.from_pretrained(args.pretrained, use_fast=False)
    with args.input.open("rb") as handle:
        dataset = pickle.load(handle)

    for split_name in ("train", "valid", "test"):
        split = dataset[split_name]
        split["text_bert"] = tokenize_split(
            tokenizer, split["raw_text"], args.max_length
        )
        print(f"{split_name}: {split['text_bert'].shape}")

    args.output.parent.mkdir(parents=True, exist_ok=True)
    temporary_path = args.output.with_suffix(args.output.suffix + ".tmp")
    with temporary_path.open("wb") as handle:
        pickle.dump(dataset, handle, protocol=pickle.HIGHEST_PROTOCOL)
    temporary_path.replace(args.output)
    print(f"Saved {args.output}")


if __name__ == "__main__":
    main()