"""Export fixed-epoch checkpoint predictions for reproducible offline figures."""

import argparse
import hashlib
import json
from pathlib import Path

import torch
from torch.utils.data import DataLoader

from config import get_config_regression
from data_loader import MMDataset
from trains.singleTask.DLF import DLF as Trainer
from trains.singleTask.model.SerialDLF import DLF


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--checkpoint', type=Path, required=True)
    parser.add_argument('--config', type=Path, default=Path('config/config.json'))
    parser.add_argument('--dataset', choices=('mosi', 'mosei'), default='mosi')
    parser.add_argument('--epoch', type=int)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--device', default='cpu')
    args = parser.parse_args()
    checkpoint = args.checkpoint.resolve()
    if not checkpoint.is_file():
        raise FileNotFoundError(checkpoint)
    config = get_config_regression('DLF', args.dataset, str(args.config))
    config.featurePath = str(Path(config.featurePath).resolve())
    config.feature_T = config.feature_A = config.feature_V = ''
    config.train_mode = 'regression'
    config.is_training = False
    config.mode = 'test'
    config.device = torch.device(args.device)
    dataset = MMDataset(config, mode='test')
    config.seq_lens = dataset.get_seq_len()
    model = DLF(config).to(config.device)
    model.load_state_dict(torch.load(checkpoint, map_location=config.device, weights_only=True), strict=True)
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=False)
    config.test_predictions_path = str(output / 'test_predictions.json')
    effective = dict(config)
    effective['device'] = str(config.device)
    (output / 'effective_config.json').write_text(json.dumps(effective, indent=2))
    (output / 'config.json').write_bytes(args.config.read_bytes())
    loader = DataLoader(dataset, batch_size=config.batch_size, shuffle=False, num_workers=0)
    metrics = Trainer(config).do_test(model, loader, mode='TEST', return_sample_results=True)
    (output / 'metrics.json').write_text(json.dumps(metrics, indent=2))
    with checkpoint.open('rb') as handle:
        digest = hashlib.file_digest(handle, 'sha256').hexdigest()
    metadata = {
        'epoch': args.epoch,
        'selection_metric': (
            'Explicit fixed epoch; not validation-selected' if args.epoch is not None
            else 'Main checkpoint file; selection epoch not supplied'
        ),
        'checkpoint': str(checkpoint), 'checkpoint_sha256': digest,
        'config_source': str(args.config.resolve()),
        'config_provenance': 'Current configuration snapshot at inference; not a saved training-time snapshot',
        'seed': None,
    }
    (output / 'checkpoint_metadata.json').write_text(json.dumps(metadata, indent=2))
    print(json.dumps(metrics, indent=2))
    print(f'Saved predictions to {output}')


if __name__ == '__main__':
    main()