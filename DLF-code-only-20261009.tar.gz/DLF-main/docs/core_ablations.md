# Core structural ablations

The queue in `run_core_ablations.py` retrains each variant independently. The
default suite is MOSI, seed 1111: four ablations followed by a matched full-model
reference. Old paper scores are not used as the matched reference. The global
configuration and `train.py` are not changed.

## Definitions

| Variant | Intervention | Auxiliary objectives |
| --- | --- | --- |
| `unsplit-residual` | Pool the conserved residual `P + Q`; use one scaled residual head (the existing support head); no conflict correction or conflict retrieval | Disable routing, three-way decorrelation, conflict ranking/delta penalties, directional and support-specific task supervision |
| `no-support` | Set the additive support correction to zero; retain support representations used by language anchoring and decomposition | Disable support task and support direction terms; retain conflict direction and routing |
| `no-conflict` | Set the additive conflict correction to zero; bypass conflict retrieval; retain conflict representations for decomposition/routing | Disable conflict direction, ranking and delta penalties; retain support supervision |
| `no-language-anchor` | Replace conflict attention with modality-balanced pooling of audio/visual conflict, duplicated into the two evidence inputs; zero the direct language-anchor input to the conflict head | Retain the full model's active losses |
| `full` | Original prediction and training paths | Original active losses |

The no-anchor variant does not remove language from the consensus or from
upstream cross-modal interaction. It replaces the complete language-conditioned
retrieval mechanism, rather than isolating only the anchor offset in attention.
These are correction/mechanism ablations, not complete deletion of all tensors
associated with a modality or branch. Unused modules may remain allocated, so
parameter counts should distinguish allocated and prediction-active parameters.

The core suite keeps optional support-scale supervision disabled and sets
`cred_support_gate_weight=0`, preserving the original core experiment objective.
The separate Table 5 suite enables this objective and retrains its own full
reference; see `docs/table5_ablations.md`. Do not mix the two full references.

## Run

```bash
.venv/bin/python -u run_core_ablations.py
.venv/bin/python -u run_core_ablations.py --datasets mosi mosei --seeds 1111 1112 1113
.venv/bin/python -u run_core_ablations.py --wait-pids 12345
.venv/bin/python run_core_ablations.py --dry-run
```

`--wait-pids` waits for existing Linux processes to exit without terminating
them. Do not launch another GPU training job while the suite is running.
`--variants` selects jobs; `--gpu` selects the GPU. `--max-epochs 1` is a smoke
test only and must not be reported as a full experiment.

Each invocation creates a new timestamped directory under
`experiments/core-ablations/`, containing:

- Frozen Python source and SHA-256 hashes in `source/` and `manifest.json`.
- Frozen global configuration and per-job effective configurations.
- Independent checkpoint, console/training logs, CSV and `metrics.json` for
  each dataset/seed/variant.
- `checkpoint_metadata.json` records the selected epoch, validation metrics,
  seed and checkpoint path.
- `test_predictions.json`, exported only after loading the checkpoint selected
  by validation `Loss`, with IDs, labels, consensus, both corrections and output.
- Job status and timestamps in `manifest.json`. A failed job stops the queue.

The current trainer's `Loss` is a mean of batch L1 losses, which is not exactly
sample-weighted MAE when the final batch is smaller. Keep this selection rule
identical across the initial suite and report it accurately. Existing per-epoch
test logging remains, but it does not select the checkpoint.

Before using results in the paper, verify token/audio/video alignment provenance,
complete multi-seed runs, and audit binary metrics' neutral-label convention.