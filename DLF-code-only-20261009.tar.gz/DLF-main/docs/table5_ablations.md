# Table 5: modality contributions and auxiliary objectives

This suite retrains seven variants on CMU-MOSI with fine-tuned DeBERTa.
Global configuration and existing Table 4 artifacts are not modified.

| Variant | Change from matched full model |
| --- | --- |
| full | All modalities and all three auxiliary objectives |
| language-only | Language donor/pooling/probe supervision only; no AV conflict correction or cross-modal routing supervision |
| language-audio | Language/audio donor attention, pooling and auxiliary supervision only |
| language-vision | Language/vision donor attention, pooling and auxiliary supervision only |
| no-routing-loss | Set `cred_routing_weight=0`; keep routing architecture |
| no-support-scale-loss | Set `cred_support_gate_weight=0`; keep learned support scale |
| no-directional-loss | Set `cred_effect_weight=0`; remove both support and conflict direction penalties |

## Modality adaptation

Missing modalities are excluded from donor attention, prediction pooling,
shared-probe disagreement targets, reconstruction, shared/private orthogonality,
and cycle/alignment supervision. Their private/shared encoder calls are skipped.
Unused projection/decoder/probe parameters remain allocated for checkpoint
compatibility but do not receive gradients from the active objective.

Two-modality models have one donor per target (donor weight exactly one).
The language-only model uses its own normalized shared representation for
consensus and a neutral agreement gate of 0.5; its learned residual router
remains. There is no donor attention, AV retrieval, or conflict correction.
Cross-modal routing supervision is disabled because a single probe cannot
provide cross-modal disagreement. Other applicable losses remain unchanged.
These are retrained reduced models, not full-model evaluations with zero inputs.

## Continuous scale supervision

The full Table 5 reference explicitly enables `enable_support_scale_loss=true`.
The additional loss is unweighted Smooth L1 between the predicted support scale
and the detached target `clip((label - consensus) / raw_support, 0, 1)`.
Samples with `abs(raw_support) < 1e-4` are excluded. The target has no gradient
to consensus, raw support, or labels. The loss coefficient is 0.05.

This objective is opt-in: ordinary training and the core ablation suite keep it
disabled, preserving their previous behavior despite legacy scale configuration
fields. Historical core/full results are not the matched full reference for
Table 5 and must not be copied into this table.

## Run and artifacts

```bash
.venv/bin/python -u run_core_ablations.py --suite table5 --datasets mosi --seeds 1111 --gpu 0
```

Each suite freezes source/config under `experiments/table5-ablations/<timestamp>`.
Each job has its own effective configuration, log, validation-selected
checkpoint, best-epoch metadata, test metrics and per-sample predictions.
The manifest records sequential progress. After each completed job,
`summary.csv` and `summary.md` are refreshed from the saved metrics; the CSV
retains raw fractions while Markdown shows accuracy/F1 as percentages.
Test Acc2/F1 exclude zero labels. Checkpoint selection remains validation Loss,
not test metrics. A single seed is a preliminary ablation, not statistical
evidence of an improvement; use repeated seeds for the final paper table.

```bash
.venv/bin/python -m unittest discover -s tests -p test_table5_ablations.py -v
```

The focused test covers all seven workers on CPU for one epoch, finite reduced
model outputs/losses, ignored-modality and padding invariance, omitted parameter
gradients, single-donor behavior, detached/clipped scale targets and summary
generation. It does not replace the full GPU experiments.