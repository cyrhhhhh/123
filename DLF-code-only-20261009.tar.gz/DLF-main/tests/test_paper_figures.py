import unittest

import numpy as np

from plot_paper_figures import analyze, gain_summary


class PaperFiguresTest(unittest.TestCase):
    def prediction(self, identity, target, baseline, support, conflict):
        return {'id': identity, 'target': target, 'consensus_logit': baseline,
                'support_delta': support, 'conflict_delta': conflict,
                'output_logit': baseline + support + conflict}

    def test_clipped_numpy_rounding_and_empty_rows(self):
        rows = [self.prediction('a', -4, -4, 0, 0),
                self.prediction('b', 0.5, 1.5, 0, 0),
                self.prediction('c', 4, 4, 0, 0)]
        data = analyze(rows)
        self.assertEqual(data['counts'][0, 0], 1)
        self.assertEqual(data['counts'][3, 5], 1)
        self.assertEqual(data['counts'][6, 6], 1)
        self.assertAlmostEqual(data['acc7'], 2 / 3)
        self.assertTrue(np.isnan(data['normalized'][1]).all())
        self.assertTrue(np.allclose(np.nansum(data['normalized'], axis=1)[[0, 3, 6]], 1))

    def test_gain_conservation_and_fractions(self):
        rows = [self.prediction('a', 1, 0, 0.7, 0.1),
                self.prediction('b', 0, 0, 0, 0),
                self.prediction('c', 0, 0.1, 0.2, 0.4)]
        data = analyze(rows)
        for protocol in ('sequential', 'averaged'):
            gains = data[protocol]
            self.assertTrue(np.allclose(gains['Support'] + gains['Conflict'], gains['Total']))
            for summary in gain_summary(gains).values():
                self.assertAlmostEqual(sum(summary[key] for key in
                                           ('helpful_fraction', 'unchanged_fraction', 'harmful_fraction')), 1)
        self.assertAlmostEqual(data['mae'][3], (0.2 + 0 + 0.7) / 3)

    def test_invalid_predictions_are_rejected(self):
        with self.assertRaises(ValueError):
            analyze([])
        row = self.prediction('a', 0, 0, 0, 0)
        with self.assertRaises(ValueError):
            analyze([row, row])
        row['output_logit'] = 1
        with self.assertRaises(ValueError):
            analyze([row])
        row['output_logit'] = float('nan')
        with self.assertRaises(ValueError):
            analyze([row])


if __name__ == '__main__':
    unittest.main()