import json
from pathlib import Path
from tempfile import TemporaryDirectory
import unittest

from prepare_table6 import build_rows, select_cases, write_outputs


class Table6Test(unittest.TestCase):
    def setUp(self):
        self.split = {'id': ['support', 'conflict', 'failure'],
                      'raw_text': ['good', 'not good', 'mixed'],
                      'regression_labels': [1.0, -1.0, 0.0]}
        self.predictions = [
            {'id': 'support', 'target': 1.0, 'consensus_logit': 0.0,
             'support_delta': 0.7, 'conflict_delta': 0.1, 'output_logit': 0.8},
            {'id': 'conflict', 'target': -1.0, 'consensus_logit': 0.0,
             'support_delta': 0.1, 'conflict_delta': -0.8, 'output_logit': -0.7},
            {'id': 'failure', 'target': 0.0, 'consensus_logit': 0.1,
             'support_delta': 0.2, 'conflict_delta': 0.4, 'output_logit': 0.7},
        ]

    def test_matching_is_by_id_and_contributions_sum_to_total(self):
        rows = build_rows(list(reversed(self.predictions)), self.split)
        self.assertEqual(rows[0]['transcript'], 'mixed')
        for row in rows:
            self.assertAlmostEqual(row['support_gain'] + row['conflict_gain'], row['total_gain'])
            self.assertAlmostEqual(row['support_order_averaged_gain']
                                   + row['conflict_order_averaged_gain'], row['total_gain'])
        candidates, selected = select_cases(rows)
        self.assertEqual([row['id'] for row in selected], ['support', 'conflict', 'failure'])
        self.assertEqual(len(candidates), 3)

    def test_rejects_incomplete_duplicate_and_mismatched_predictions(self):
        with self.assertRaises(ValueError):
            build_rows(self.predictions[:-1], self.split)
        with self.assertRaises(ValueError):
            build_rows(self.predictions + self.predictions[:1], self.split)
        self.predictions[0]['target'] = 2.0
        with self.assertRaises(ValueError):
            build_rows(self.predictions, self.split)
        self.predictions[0]['target'] = 1.0
        self.predictions[0]['output_logit'] = 5.0
        with self.assertRaises(ValueError):
            build_rows(self.predictions, self.split)

    def test_cannot_invent_missing_categories(self):
        rows = build_rows(self.predictions, self.split)
        with self.assertRaises(ValueError):
            select_cases(rows[:1])

    def test_export_keeps_pending_clip_review_and_refuses_overwrite(self):
        rows = build_rows(self.predictions, self.split)
        candidates, selected = select_cases(rows)
        with TemporaryDirectory() as directory:
            output = Path(directory) / 'table6'
            write_outputs(output, rows, candidates, selected, {'seed': 1111})
            payload = json.loads((output / 'cases.json').read_text())
            self.assertEqual(len(payload['selected']), 3)
            self.assertEqual(len((output / 'all_samples.csv').read_text().splitlines()), 4)
            self.assertIn('original-clip review', (output / 'table6.md').read_text())
            self.assertTrue(all(row['visual_cues'].startswith('Pending') for row in payload['selected']))
            with self.assertRaises(FileExistsError):
                write_outputs(output, rows, candidates, selected, {})


if __name__ == '__main__':
    unittest.main()