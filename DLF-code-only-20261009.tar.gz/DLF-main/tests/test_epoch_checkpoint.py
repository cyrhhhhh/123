from pathlib import Path
from tempfile import TemporaryDirectory
from types import SimpleNamespace
import unittest

import torch

from trains.singleTask.DLF import DLF


class EpochCheckpointTest(unittest.TestCase):
    def test_requested_epoch_is_separate_from_best(self):
        with TemporaryDirectory() as directory:
            best_path = Path(directory) / 'model.pth'
            model = torch.nn.Linear(2, 1)
            torch.save({'best': torch.tensor(7)}, best_path)
            trainer = DLF.__new__(DLF)
            trainer.args = SimpleNamespace(model_save_path=best_path, save_checkpoint_epochs=[31])
            trainer._save_requested_epoch(model, 30)
            epoch_path = best_path.with_name('model-epoch-31.pth')
            self.assertFalse(epoch_path.exists())
            trainer._save_requested_epoch(model, 31)
            restored = torch.load(epoch_path, weights_only=True)
            for name, tensor in model.state_dict().items():
                self.assertTrue(torch.equal(restored[name], tensor))
            self.assertEqual(torch.load(best_path, weights_only=True)['best'].item(), 7)

    def test_missing_option_does_not_save(self):
        trainer = DLF.__new__(DLF)
        trainer.args = SimpleNamespace()
        trainer._save_requested_epoch(torch.nn.Linear(2, 1), 31)


if __name__ == '__main__':
    unittest.main()