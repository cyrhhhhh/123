import argparse
import json
from pathlib import Path
from tempfile import TemporaryDirectory
import unittest
from unittest.mock import patch

import torch

from run_core_ablations import prepare_suite, run_worker, variant_overrides
from test_serial_ccdr import make_args
from trains.singleTask.DLF import DLF as Trainer
from trains.singleTask.model.SerialDLF import DLF


class CoreAblationTest(unittest.TestCase):
    def setUp(self):
        torch.manual_seed(17)
        self.text = torch.randn(2, 8, 6)
        self.audio = torch.randn(2, 8, 4)
        self.video = torch.randn(2, 8, 5)
        self.mask = torch.tensor([
            [False, False, False, False, True, True, True, True],
            [False, False, False, False, False, True, True, True],
        ])

    def build(self, variant):
        args = make_args()
        vars(args).update(variant_overrides(variant))
        args.train_mode = 'regression'
        args.dataset_name = 'mosi'
        args.model_name = 'DLF'
        return args, DLF(args).eval()

    def forward(self, model):
        return model(self.text, self.audio, self.video, self.mask)

    def test_four_variants_forward_backward_and_padding(self):
        for variant in ('unsplit-residual', 'no-support', 'no-conflict', 'no-language-anchor'):
            with self.subTest(variant=variant):
                args, model = self.build(variant)
                output = self.forward(model)
                self.assertTrue(torch.isfinite(output['output_logit']).all())
                self.assertTrue(torch.allclose(
                    output['output_logit'], output['consensus_logit']
                    + output['support_delta'] + output['conflict_delta'],
                ))
                padded = self.mask.unsqueeze(-1)
                changed = model(
                    self.text.masked_fill(padded, 1000.0),
                    self.audio.masked_fill(padded, -1000.0),
                    self.video.masked_fill(padded, 1000.0), self.mask,
                )
                self.assertTrue(torch.allclose(
                    output['output_logit'], changed['output_logit'], atol=1e-6,
                ))
                losses = Trainer(args)._ccdr_losses(output, torch.ones(2, 1))
                (output['output_logit'].abs().mean() + sum(losses)).backward()
                if variant == 'no-support':
                    self.assertEqual(output['support_delta'].abs().sum().item(), 0.0)
                    self.assertEqual(losses[6].item(), 0.0)
                    self.assertTrue(all(parameter.grad is None
                                        for parameter in model.ccdr.support_head.parameters()))
                if variant in ('unsplit-residual', 'no-conflict'):
                    self.assertEqual(output['conflict_delta'].abs().sum().item(), 0.0)
                    self.assertTrue(all(parameter.grad is None
                                        for parameter in model.ccdr.adjudication_head.parameters()))
                if variant == 'unsplit-residual':
                    for index in (1, 2, 3, 4, 5, 6):
                        self.assertEqual(losses[index].item(), 0.0)

    def test_unsplit_prediction_does_not_depend_on_router(self):
        _, model = self.build('unsplit-residual')
        with torch.no_grad():
            before = self.forward(model)['output_logit']
            for router in model.ccdr.disentangler.residual_routers:
                for parameter in router.parameters():
                    parameter.fill_(100.0)
            after = self.forward(model)['output_logit']
        self.assertTrue(torch.allclose(before, after, atol=1e-6))

    def test_no_anchor_prediction_bypasses_query_and_attention_parameters(self):
        _, model = self.build('no-language-anchor')
        with torch.no_grad():
            before = self.forward(model)['output_logit']
            model.ccdr.support_slot.fill_(100.0)
            model.ccdr.reverse_slot.fill_(-100.0)
            for parameter in model.ccdr.evidence_attention.parameters():
                parameter.fill_(100.0)
            after = self.forward(model)
        self.assertIsNone(after['evidence_attention'])
        self.assertTrue(torch.equal(before, after['output_logit']))

    def test_final_prediction_export(self):
        args, model = self.build('no-conflict')
        batch = {
            'text': self.text, 'audio': self.audio, 'vision': self.video,
            'padding_mask': self.mask, 'id': ['sample-a', 'sample-b'],
            'labels': {'M': torch.tensor([[1.0], [-1.0]])},
        }
        args.device = 'cpu'
        with TemporaryDirectory() as directory:
            args.test_predictions_path = str(Path(directory) / 'predictions.json')
            metrics = Trainer(args).do_test(model, [batch], return_sample_results=True)
            records = json.loads(Path(args.test_predictions_path).read_text())
        self.assertIn('MAE', metrics)
        self.assertEqual(len(records), 2)
        self.assertEqual(records[0]['id'], 'sample-a')
        for record in records:
            self.assertAlmostEqual(record['output_logit'], record['consensus_logit']
                                   + record['support_delta'] + record['conflict_delta'], places=6)

    def test_prepared_suite_freezes_config_and_isolates_jobs(self):
        with TemporaryDirectory() as directory:
            args = argparse.Namespace(
                output=Path(directory) / 'suite', datasets=['mosi', 'mosei'],
                variants=['unsplit-residual', 'no-support', 'no-conflict',
                          'no-language-anchor', 'full'], seeds=[1111],
                gpu=0, max_epochs=1, wait_pids=[],
            )
            root, manifest = prepare_suite(args)
            self.assertEqual(len(manifest['jobs']), 10)
            self.assertTrue((root / 'source/run_core_ablations.py').is_file())
            self.assertEqual(len({job['path'] for job in manifest['jobs']}), 10)
            for job in manifest['jobs']:
                effective = json.loads((Path(job['path']) / 'effective_config.json').read_text())
                self.assertEqual(effective['transformers'], 'deberta')
                self.assertEqual(effective['max_epochs'], 1)
                self.assertEqual(effective['cred_support_gate_weight'], 0.0)
                self.assertTrue(Path(effective['featurePath']).is_absolute())

    def test_each_worker_trains_reloads_and_exports_on_cpu(self):
        import run

        batch = {
            'text': self.text, 'audio': self.audio, 'vision': self.video,
            'padding_mask': self.mask, 'id': ['sample-a', 'sample-b'],
            'labels': {'M': torch.tensor([[1.0], [-1.0]])},
        }
        loaders = {split: [batch] for split in ('train', 'valid', 'test')}
        config_path = Path(__file__).resolve().parents[1] / 'config/config.json'
        with TemporaryDirectory() as directory:
            for variant in ('unsplit-residual', 'no-support', 'no-conflict',
                            'no-language-anchor', 'full'):
                with self.subTest(variant=variant):
                    root = Path(directory) / variant
                    (root / 'log').mkdir(parents=True)
                    overrides = {
                        **vars(make_args()), **variant_overrides(variant),
                        'max_epochs': 1, 'update_epochs': 1,
                    }
                    job_path = root / 'job.json'
                    job_path.write_text(json.dumps({
                        'dataset': 'mosi', 'seed': 1111, 'gpu': 0,
                        'config_file': str(config_path), 'overrides': overrides,
                    }))
                    with patch.object(run, 'assign_gpu', return_value=torch.device('cpu')), \
                         patch.object(run, 'MMDataLoader', return_value=loaders), \
                         patch.object(run, '_set_logger', return_value=run.logger):
                        run_worker(job_path)
                    metrics = json.loads((root / 'metrics.json').read_text())
                    predictions = json.loads((root / 'test_predictions.json').read_text())
                    self.assertIn('MAE', metrics)
                    self.assertEqual(len(predictions), 2)
                    metadata = json.loads((root / 'checkpoint_metadata.json').read_text())
                    self.assertEqual(metadata['epoch'], 1)
                    self.assertEqual(metadata['selection_metric'], 'Loss')
                    self.assertEqual(len(list((root / 'pt').glob('*.pth'))), 1)
                    self.assertEqual(len(list((root / 'result/normal').glob('*.csv'))), 1)


if __name__ == '__main__':
    unittest.main()