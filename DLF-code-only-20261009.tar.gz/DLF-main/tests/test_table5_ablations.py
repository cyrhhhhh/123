import argparse
import json
from pathlib import Path
from tempfile import TemporaryDirectory
import unittest
from unittest.mock import patch

import torch
import torch.nn.functional as F

from run_core_ablations import (
    TABLE5_VARIANTS, prepare_suite, run_worker, summarize_suite, variant_overrides,
)
from test_serial_ccdr import make_args
from trains.singleTask.DLF import DLF as Trainer
from trains.singleTask.model.SerialDLF import DLF


class Table5Test(unittest.TestCase):
    def setUp(self):
        torch.manual_seed(17)
        self.inputs = [torch.randn(2, 8, width) for width in (6, 4, 5)]
        self.mask = torch.tensor([
            [False, False, False, False, True, True, True, True],
            [False, False, False, False, False, True, True, True],
        ])
        self.labels = torch.tensor([[1.0], [-1.0]])

    def build(self, variant):
        args = make_args()
        vars(args).update(variant_overrides(variant, 'table5'))
        args.train_mode, args.dataset_name = 'regression', 'mosi'
        return args, DLF(args).eval()

    def test_modality_paths_are_finite_and_omit_absent_modalities(self):
        for variant in TABLE5_VARIANTS:
            with self.subTest(variant=variant):
                args, model = self.build(variant)
                output = model(*self.inputs, self.mask)
                active = args.active_modalities
                self.assertEqual(len(output['consensus_parts']), len(active))
                self.assertEqual(len(output['ccdr_padding_masks']), len(active))
                self.assertTrue(torch.isfinite(output['output_logit']).all())
                changed = [feature.clone() for feature in self.inputs]
                for index in range(3):
                    if index not in active:
                        changed[index].fill_(1000)
                    changed[index].masked_fill_(self.mask.unsqueeze(-1), -1000)
                after = model(*changed, self.mask)
                self.assertTrue(torch.allclose(output['output_logit'], after['output_logit'], atol=1e-6))
                losses = Trainer(args)._ccdr_losses(output, self.labels)
                for loss in losses:
                    self.assertTrue(torch.isfinite(loss))
                for before_loss, after_loss in zip(losses, Trainer(args)._ccdr_losses(after, self.labels)):
                    self.assertTrue(torch.allclose(before_loss, after_loss, atol=1e-6))
                total = output['output_logit'].abs().mean() + sum(losses)
                total = total + Trainer(args)._support_scale_loss(output, self.labels)
                total.backward()
                for index, suffix in ((1, 'a'), (2, 'v')):
                    if index not in active:
                        for name in ('proj_', 'encoder_s_', 'shared_probe_'):
                            self.assertTrue(all(parameter.grad is None for parameter in
                                                getattr(model, name + suffix).parameters()))
                        self.assertTrue(all(parameter.grad is None for parameter in
                                            model.ccdr.disentangler.residual_routers[index].parameters()))
                if len(active) == 1:
                    self.assertEqual(losses[4].item(), 0)
                    self.assertEqual(output['conflict_delta'].abs().sum().item(), 0)
                    self.assertIsNone(output['evidence_attention'])
                    self.assertEqual(output['donor_weights'][0].shape[-1], 0)
                elif len(active) == 2:
                    for weights in output['donor_weights']:
                        self.assertTrue(torch.equal(weights, torch.ones_like(weights)))

    def test_scale_target_is_detached_clipped_and_thresholded(self):
        args, _ = self.build('full')
        baseline = torch.tensor([[0.0], [0.0], [0.0], [0.0]], requires_grad=True)
        raw = torch.tensor([[2.0], [-2.0], [1.0], [1e-5]], requires_grad=True)
        scale = torch.tensor([[0.1], [0.2], [0.9], [0.8]], requires_grad=True)
        labels = torch.tensor([[1.0], [1.0], [4.0], [-1.0]], requires_grad=True)
        output = {'output_logit': baseline + raw * scale, 'consensus_logit': baseline,
                  'support_delta_raw': raw, 'support_scale': scale}
        loss = Trainer(args)._support_scale_loss(output, labels)
        expected = F.smooth_l1_loss(scale[:3], torch.tensor([[0.5], [0.0], [1.0]]))
        self.assertTrue(torch.allclose(loss, expected))
        loss.backward()
        self.assertIsNone(baseline.grad)
        self.assertIsNone(raw.grad)
        self.assertIsNone(labels.grad)
        self.assertEqual(scale.grad[3].item(), 0)
        args.enable_support_scale_loss = False
        self.assertEqual(Trainer(args)._support_scale_loss(output, labels).item(), 0)
        args.enable_support_scale_loss = True
        output['support_delta_raw'] = torch.zeros_like(raw)
        self.assertEqual(Trainer(args)._support_scale_loss(output, labels).item(), 0)

    def test_loss_variants_change_only_one_setting(self):
        full = variant_overrides('full', 'table5')
        for variant, key in (
            ('no-routing-loss', 'cred_routing_weight'),
            ('no-support-scale-loss', 'cred_support_gate_weight'),
            ('no-directional-loss', 'cred_effect_weight'),
        ):
            overrides = variant_overrides(variant, 'table5')
            differences = {name for name in overrides if overrides[name] != full.get(name)}
            self.assertEqual(differences, {key, 'ablation_name'})
            self.assertEqual(overrides[key], 0)

    def test_all_workers_train_reload_export_and_summarize(self):
        import run

        batch = dict(zip(('text', 'audio', 'vision'), self.inputs))
        batch.update(padding_mask=self.mask, id=['a', 'b'], labels={'M': self.labels})
        loaders = {split: [batch] for split in ('train', 'valid', 'test')}
        with TemporaryDirectory() as directory:
            args = argparse.Namespace(
                suite='table5', output=Path(directory) / 'suite', datasets=['mosi'],
                variants=list(TABLE5_VARIANTS), seeds=[1111], gpu=0, max_epochs=1, wait_pids=[],
            )
            root, manifest = prepare_suite(args)
            self.assertEqual(len(manifest['jobs']), 7)
            for job in manifest['jobs']:
                with self.subTest(variant=job['variant']):
                    job_path = Path(job['path']) / 'job.json'
                    worker_job = json.loads(job_path.read_text())
                    worker_job['overrides'] = {**vars(make_args()), **worker_job['overrides'], 'update_epochs': 1}
                    job_path.write_text(json.dumps(worker_job))
                    with patch.object(run, 'assign_gpu', return_value=torch.device('cpu')), \
                         patch.object(run, 'MMDataLoader', return_value=loaders), \
                         patch.object(run, '_set_logger', return_value=run.logger):
                        run_worker(job_path)
                    job['status'] = 'completed'
                    job['metrics'] = json.loads((job_path.parent / 'metrics.json').read_text())
                    records = json.loads((job_path.parent / 'test_predictions.json').read_text())
                    self.assertEqual(len(records), 2)
                    self.assertEqual(len(list((job_path.parent / 'pt').glob('*.pth'))), 1)
            summarize_suite(root, manifest)
            self.assertEqual(len((root / 'summary.csv').read_text().splitlines()), 8)
            self.assertIn('no-support-scale-loss', (root / 'summary.md').read_text())


if __name__ == '__main__':
    unittest.main()