import unittest

from plot_polarity_corrections import evaluate


class PolarityCorrectionTest(unittest.TestCase):
    def test_zero_labels_excluded_and_zero_prediction_is_negative(self):
        rows = [
            {'id': 'a', 'target': 1, 'consensus_logit': -0.1, 'support_delta': 0.3,
             'conflict_delta': 0, 'output_logit': 0.2},
            {'id': 'b', 'target': -1, 'consensus_logit': -0.1, 'support_delta': 0.3,
             'conflict_delta': 0, 'output_logit': 0.2},
            {'id': 'c', 'target': 0, 'consensus_logit': -1, 'support_delta': 2,
             'conflict_delta': 0, 'output_logit': 1},
            {'id': 'd', 'target': -1, 'consensus_logit': 0, 'support_delta': 0,
             'conflict_delta': 0, 'output_logit': 0},
        ]
        result = evaluate(rows)
        self.assertEqual(result['nonzero_count'], 3)
        self.assertEqual(result['excluded_zero_count'], 1)
        self.assertEqual(result['transitions']['Full'], {
            'Wrong to correct': 1, 'Correct to wrong': 1, 'Remain correct': 1, 'Remain wrong': 0,
        })
        for name, counts in result['transitions'].items():
            self.assertEqual(sum(counts.values()), 3)
            delta = result['metrics'][name]['Acc2'] - result['metrics']['b']['Acc2']
            self.assertAlmostEqual(delta, (counts['Wrong to correct'] - counts['Correct to wrong']) / 3)

    def test_all_zero_labels_rejected(self):
        with self.assertRaises(ValueError):
            evaluate([{'id': 'a', 'target': 0, 'consensus_logit': 0,
                       'support_delta': 0, 'conflict_delta': 0, 'output_logit': 0}])


if __name__ == '__main__':
    unittest.main()