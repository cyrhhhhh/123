import argparse
import csv
import json
import math
import re
from pathlib import Path


METRICS = ('acc_7', 'acc_5', 'acc_2', 'F1_score', 'MAE', 'Corr', 'Loss', 'total_loss')
SOURCES = {
    7: 'mosei-table4-7epochs/20261007-044116-004033',
    4: 'mosei-table4-4epochs/20261007-054511-663011/suite',
}


def collect_rows(summary_path):
    rows = []
    with summary_path.open() as stream:
        experiments = list(csv.DictReader(stream))
    for experiment in experiments:
        budget = int(experiment['training_epochs'])
        job = summary_path.parent / SOURCES[budget] / 'mosei' / experiment['seed'] / experiment['variant']
        metadata = json.loads((job / 'checkpoint_metadata.json').read_text())
        selected_epoch = metadata['epoch']
        epoch = None
        measured = {}
        for line in (job / 'log/DLF-mosei.log').read_text().splitlines():
            match = re.search(r'>> Epoch: (\d+) TRAIN', line)
            if match:
                epoch = int(match.group(1))
                split = 'train'
            elif 'VAL-(DLF) >>' in line:
                split = 'validation'
            elif 'TEST-(DLF) >>' in line:
                split = 'test'
            else:
                continue
            assert epoch is not None
            key = (epoch, split)
            if key in measured:
                assert split == 'test' and epoch == budget
                continue
            values = {
                name: float(value)
                for name, value in re.findall(r'(\w+):\s*(-?\d+(?:\.\d+)?)', line)
                if name in METRICS
            }
            expected = set(METRICS) - {'Loss' if split == 'train' else 'total_loss'}
            assert set(values) == expected, (job, epoch, split, values)
            measured[key] = values
            rows.append({
                'variant': experiment['variant'],
                'epoch': epoch,
                'split': split,
                'selected_checkpoint': epoch == selected_epoch,
                **{metric: values.get(metric, '') for metric in METRICS},
            })
        assert set(measured) == {
            (epoch_number, split_name)
            for epoch_number in range(1, budget + 1)
            for split_name in ('train', 'validation', 'test')
        }, job
        assert selected_epoch == int(experiment['selected_epoch'])
        for split_name, reference in (
            ('validation', metadata['validation_metrics']),
            ('test', json.loads((job / 'metrics.json').read_text())),
        ):
            for metric, value in reference.items():
                assert math.isclose(measured[selected_epoch, split_name][metric], value, abs_tol=1e-8)
    return rows


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--summary', type=Path, default=Path(__file__).parent / 'experiments/mosei-table4-summary-20261007.csv')
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    output = args.output or args.summary.with_name('mosei-table4-all-epochs-20261007')
    rows = collect_rows(args.summary)
    with output.with_suffix('.csv').open('w', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    lines = [
        '# MOSEI Table 4: all epoch metrics',
        '',
        'Encoder: DeBERTa v3 base. Seed: 1111. Accuracy/F1 are percentages in this table; CSV uses fractions.',
        'Selected marks the validation-Loss-selected epoch. Final checkpoint re-evaluation is excluded.',
        'Training total_loss includes auxiliary objectives; validation/test Loss is batch-averaged L1.',
        'A dash means the metric is not logged for that split. Training budgets differ (7 vs 4 epochs).',
        '',
        '| Variant | Epoch | Split | Selected | Acc7 | Acc5 | Acc2 | F1 | MAE | Corr | Loss | Total loss |',
        '| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |',
    ]
    for row in rows:
        cells = [row['variant'], str(row['epoch']), row['split'], 'yes' if row['selected_checkpoint'] else '']
        for metric in METRICS:
            value = row[metric]
            cells.append('-' if value == '' else (
                f'{value * 100:.2f}' if metric in METRICS[:4] else f'{value:.4f}'
            ))
        lines.append('| ' + ' | '.join(cells) + ' |')
    output.with_suffix('.md').write_text('\n'.join(lines) + '\n')
    print(f'Validated and exported {len(rows)} rows ({len(rows) // 3} epochs across five variants).')
    print(output.with_suffix('.md'))
    print(output.with_suffix('.csv'))


if __name__ == '__main__':
    main()