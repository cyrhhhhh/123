"""Plot classification performance and polarity transitions for a fixed model."""

import argparse
import json
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
from sklearn.metrics import accuracy_score, f1_score

from plot_paper_figures import analyze


def evaluate(predictions):
    analyze(predictions)
    target = np.array([row['target'] for row in predictions])
    baseline = np.array([row['consensus_logit'] for row in predictions])
    support = np.array([row['support_delta'] for row in predictions])
    conflict = np.array([row['conflict_delta'] for row in predictions])
    final = np.array([row['output_logit'] for row in predictions])
    valid = target != 0
    if not valid.any():
        raise ValueError('No nonzero ground-truth labels')
    truth = target[valid] > 0
    baseline_correct = (baseline[valid] > 0) == truth
    combinations = {'b': baseline, 'b + support': baseline + support,
                    'b + conflict': baseline + conflict, 'Full': final}
    result = {'sample_count': len(target), 'nonzero_count': int(valid.sum()),
              'excluded_zero_count': int((~valid).sum()), 'metrics': {}, 'transitions': {}}
    for name, values in combinations.items():
        binary = values[valid] > 0
        correct = binary == truth
        result['metrics'][name] = {
            'Acc2': float(accuracy_score(truth, binary)),
            'weighted_F1': float(f1_score(truth, binary, average='weighted', zero_division=0)),
            'Acc7': float((np.round(np.clip(values, -3, 3)) == np.round(np.clip(target, -3, 3))).mean()),
            'MAE': float(np.abs(values - target).mean()),
            'Corr': float(np.corrcoef(values, target)[0, 1]),
        }
        if name != 'b':
            counts = {
                'Wrong to correct': int((~baseline_correct & correct).sum()),
                'Correct to wrong': int((baseline_correct & ~correct).sum()),
                'Remain correct': int((baseline_correct & correct).sum()),
                'Remain wrong': int((~baseline_correct & ~correct).sum()),
            }
            result['transitions'][name] = counts
    return result


def draw(result, output):
    figure, axes = plt.subplots(1, 2, figsize=(12.5, 4.7), layout='constrained')
    names = list(result['metrics'])
    positions = np.arange(len(names))
    for offset, field, color in ((-0.18, 'Acc2', '#247c88'), (0.18, 'weighted_F1', '#ba4d62')):
        values = [result['metrics'][name][field] * 100 for name in names]
        bars = axes[0].bar(positions + offset, values, width=0.34, color=color,
                           label='Acc2' if field == 'Acc2' else 'Weighted F1')
        axes[0].bar_label(bars, fmt='%.2f', padding=3, fontsize=8)
    axes[0].set_xticks(positions, names, fontsize=9)
    axes[0].set_ylim(0, 100)
    axes[0].set_ylabel('Performance (%)')
    axes[0].set_title('(a) Four prediction combinations')
    axes[0].legend(frameon=False, loc='lower right')
    transition_names = list(result['transitions'])
    left = np.zeros(len(transition_names))
    for field, color in (('Wrong to correct', '#498765'), ('Correct to wrong', '#c2695d'),
                        ('Remain correct', '#a9c4cb'), ('Remain wrong', '#d3d3d3')):
        counts = np.array([result['transitions'][name][field] for name in transition_names])
        widths = counts / result['nonzero_count'] * 100
        axes[1].barh(transition_names, widths, left=left, height=0.6, color=color, label=field)
        for index, count in enumerate(counts):
            if widths[index] > 8:
                axes[1].text(left[index] + widths[index] / 2, index, str(count),
                             ha='center', va='center', fontsize=9)
        left += widths
    axes[1].set_xlim(0, 100)
    axes[1].invert_yaxis()
    axes[1].set_xlabel('Nonzero-label samples (%)')
    axes[1].set_title('(b) Polarity transitions relative to b')
    axes[1].legend(frameon=False, loc='upper center', bbox_to_anchor=(0.5, -0.14), ncol=2, fontsize=8)
    summary = []
    for name in transition_names:
        counts = result['transitions'][name]
        summary.append(f'{name}: rescued {counts["Wrong to correct"]}, harmed {counts["Correct to wrong"]}')
    figure.suptitle(f'CMU-MOSI: fixed-model polarity correction analysis\n'
                   f'N={result["nonzero_count"]}; zero labels excluded; predicted positive iff > 0', fontsize=12)
    figure.supxlabel(' | '.join(summary), fontsize=9)
    figure.savefig(output / 'polarity_correction_analysis.pdf', bbox_inches='tight')
    figure.savefig(output / 'polarity_correction_analysis.png', dpi=300, bbox_inches='tight')
    plt.close(figure)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--job', type=Path, required=True)
    args = parser.parse_args()
    job = args.job.resolve()
    result = evaluate(json.loads((job / 'test_predictions.json').read_text()))
    saved = json.loads((job / 'metrics.json').read_text())
    for field, key in (('Acc2', 'acc_2'), ('weighted_F1', 'F1_score')):
        if abs(result['metrics']['Full'][field] - saved[key]) > 5.1e-5:
            raise ValueError(f'{field} disagrees with saved metrics')
    result['checkpoint_metadata'] = json.loads((job / 'checkpoint_metadata.json').read_text())
    output = job / 'polarity_figures'
    output.mkdir(parents=True, exist_ok=False)
    plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 10, 'pdf.fonttype': 42,
                         'axes.spines.top': False, 'axes.spines.right': False})
    draw(result, output)
    (output / 'statistics.json').write_text(json.dumps(result, indent=2))
    lines = ['# Fixed-model polarity corrections', '',
             'Acc2 and weighted F1 exclude zero ground-truth labels; predictions >0 are positive.',
             'All transitions compare each combination directly with b, not sequentially.',
             'Acc7, MAE and Corr use the complete test split.', '',
             '| Combination | Acc2 (%) | Weighted F1 (%) | Acc7 (%) | MAE | Corr |',
             '| --- | --- | --- | --- | --- | --- |']
    for name, values in result['metrics'].items():
        lines.append(f'| {name} | {values["Acc2"] * 100:.2f} | {values["weighted_F1"] * 100:.2f} | '
                     f'{values["Acc7"] * 100:.2f} | {values["MAE"]:.4f} | {values["Corr"]:.4f} |')
    lines.extend(['', '| Combination | Wrong to correct | Correct to wrong | Remain correct | Remain wrong |',
                  '| --- | --- | --- | --- | --- |'])
    for name, counts in result['transitions'].items():
        lines.append(f'| {name} | ' + ' | '.join(str(count) for count in counts.values()) + ' |')
    lines.extend(['', f'Checkpoint: {result["checkpoint_metadata"]["checkpoint"]}',
                  f'Selection: {result["checkpoint_metadata"]["selection_metric"]}',
                  'Classification improvements do not establish semantic or causal roles for the branches.'])
    (output / 'summary.md').write_text('\n'.join(lines) + '\n')
    print(json.dumps(result['transitions'], indent=2))
    print(f'Saved {output}')


if __name__ == '__main__':
    main()