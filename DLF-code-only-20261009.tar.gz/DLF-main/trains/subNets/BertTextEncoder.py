import torch
import torch.nn as nn
from transformers import AutoModel, AutoTokenizer

__all__ = ['BertTextEncoder']

class BertTextEncoder(nn.Module):
    def __init__(self, use_finetune=False, transformers='bert', pretrained='bert-base-uncased'):
        super().__init__()

        self.tokenizer = AutoTokenizer.from_pretrained(pretrained, use_fast=False)
        self.model = AutoModel.from_pretrained(pretrained)
        self.use_finetune = use_finetune
    
    def get_tokenizer(self):
        return self.tokenizer
    
    # def from_text(self, text):
    #     """
    #     text: raw data
    #     """
    #     input_ids = self.get_id(text)
    #     with torch.no_grad():
    #         last_hidden_states = self.model(input_ids)[0]  # Models outputs are now tuples
    #     return last_hidden_states.squeeze()
    
    def forward(self, text):
        """
        text: (batch_size, 3, seq_len)
        3: input_ids, input_mask, segment_ids
        input_ids: input_ids,
        input_mask: attention_mask,
        segment_ids: token_type_ids
        """
        input_ids, input_mask, segment_ids = text[:,0,:].long(), text[:,1,:].float(), text[:,2,:].long()
        model_inputs = {
            'input_ids': input_ids,
            'attention_mask': input_mask,
        }
        if 'token_type_ids' in self.tokenizer.model_input_names:
            model_inputs['token_type_ids'] = segment_ids
        if not self.use_finetune:
            with torch.no_grad():
                return self.model(**model_inputs).last_hidden_state
        return self.model(**model_inputs).last_hidden_state
