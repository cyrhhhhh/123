"""Draw title-free gain panels without the unchanged category."""

import argparse
import json
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np

from plot_paper_figures import COLORS, analyze, gain_summary


def draw(predictions, output):
    gains = analyze(predictions)['sequential']
    summaries = gain_summary(gains)
    plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 12,
                         'axes.spines.top': False, 'axes.spines.right': False})
    figure, axes = plt.subplots(1, 2, figsize=(11.5, 4.5), layout='constrained')
    bound = max(np.max(np.abs(gains[branch])) for branch in ('Support', 'Conflict'))
    bins = np.linspace(-max(bound, 1e-3), max(bound, 1e-3), 41)
    for branch in ('Support', 'Conflict'):
        axes[0].hist(gains[branch], bins=bins, histtype='step', linewidth=1.8,
                     label=branch, color=COLORS[branch])
    axes[0].axvline(0, color='#555555', linewidth=0.8, linestyle='--')
    axes[0].set_xlabel('Absolute-error reduction (>0 helps)')
    axes[0].set_ylabel('Samples')
    axes[0].legend(frameon=False)
    branches = list(gains)
    left = np.zeros(len(branches))
    for field, label, color in (('helpful_fraction', 'Helpful', '#498765'),
                                ('harmful_fraction', 'Harmful', '#c2695d')):
        widths = np.array([summaries[branch][field] * 100 for branch in branches])
        axes[1].barh(branches, widths, left=left, color=color, label=label, height=0.6)
        for index, width in enumerate(widths):
            if width >= 7:
                axes[1].text(left[index] + width / 2, index, f'{width:.1f}%',
                             ha='center', va='center')
        left += widths
    axes[1].set_xlim(0, 100)
    axes[1].invert_yaxis()
    axes[1].set_xlabel('Test samples (%)')
    axes[1].legend(frameon=False, loc='upper center', bbox_to_anchor=(0.5, -0.15), ncol=2)
    output.parent.mkdir(parents=True, exist_ok=True)
    figure.savefig(output, dpi=300, bbox_inches='tight')
    plt.close(figure)
    print(json.dumps(summaries, indent=2))
    print(f'Saved {output}')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--job', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    if args.output.suffix.lower() != '.png':
        parser.error('Output must be PNG')
    draw(json.loads((args.job / 'test_predictions.json').read_text()), args.output)


if __name__ == '__main__':
    main()