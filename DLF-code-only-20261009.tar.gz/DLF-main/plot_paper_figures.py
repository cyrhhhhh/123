"""Plot measured confusion and correction effects from one frozen model job."""

import argparse
import csv
import json
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np


COLORS = {'Support': '#247c88', 'Conflict': '#ba4d62', 'Total': '#666666'}
TOLERANCE = 1e-6


def analyze(predictions):
    if not predictions:
        raise ValueError('Empty predictions')
    if len({row['id'] for row in predictions}) != len(predictions):
        raise ValueError('Duplicate prediction IDs')
    values = {
        name: np.asarray([row[name] for row in predictions], dtype=float)
        for name in ('target', 'consensus_logit', 'support_delta', 'conflict_delta', 'output_logit')
    }
    if not all(np.isfinite(array).all() for array in values.values()):
        raise ValueError('Non-finite prediction values')
    target = values['target']
    baseline = values['consensus_logit']
    support = values['support_delta']
    conflict = values['conflict_delta']
    final = values['output_logit']
    if not np.allclose(final, baseline + support + conflict, rtol=0, atol=1e-5):
        raise ValueError('Additive predictions do not match')
    errors = np.stack([
        np.abs(baseline - target), np.abs(baseline + support - target),
        np.abs(baseline + conflict - target), np.abs(final - target),
    ])
    sequential = {
        'Support': errors[0] - errors[1],
        'Conflict': errors[1] - errors[3],
        'Total': errors[0] - errors[3],
    }
    averaged = {
        'Support': 0.5 * (sequential['Support'] + errors[2] - errors[3]),
        'Conflict': 0.5 * (errors[0] - errors[2] + sequential['Conflict']),
        'Total': sequential['Total'],
    }
    target_classes = np.round(np.clip(target, -3, 3)).astype(int) + 3
    predicted_classes = np.round(np.clip(final, -3, 3)).astype(int) + 3
    counts = np.zeros((7, 7), dtype=int)
    np.add.at(counts, (target_classes, predicted_classes), 1)
    support_counts = counts.sum(axis=1)
    normalized = np.divide(
        counts, support_counts[:, None],
        out=np.full((7, 7), np.nan), where=support_counts[:, None] != 0,
    )
    return {
        'errors': errors, 'sequential': sequential, 'averaged': averaged,
        'counts': counts, 'normalized': normalized, 'class_support': support_counts,
        'mae': errors.mean(axis=1), 'acc7': float(np.trace(counts) / counts.sum()),
    }


def gain_summary(gains):
    return {
        branch: {
            'mean_gain': float(values.mean()),
            'helpful_fraction': float((values > TOLERANCE).mean()),
            'unchanged_fraction': float((np.abs(values) <= TOLERANCE).mean()),
            'harmful_fraction': float((values < -TOLERANCE).mean()),
        }
        for branch, values in gains.items()
    }


def save_figure(figure, output, name, formats=('pdf', 'png')):
    for file_format in formats:
        figure.savefig(output / f'{name}.{file_format}', dpi=300, bbox_inches='tight')
    plt.close(figure)


def draw_confusion(data, output, dataset, name='figure2_mosi_confusion', formats=('pdf', 'png')):
    figure, axis = plt.subplots(figsize=(7.3, 6.3), layout='constrained')
    colormap = plt.get_cmap('Blues').copy()
    colormap.set_bad('#ededed')
    image = axis.imshow(data['normalized'] * 100, vmin=0, vmax=100, cmap=colormap)
    for row_index in range(7):
        for column_index in range(7):
            value = data['normalized'][row_index, column_index] * 100
            label = f'{value:.1f}' if np.isfinite(value) else 'N/A'
            axis.text(column_index, row_index, label, ha='center', va='center',
                      fontsize=9, color='white' if value > 50 else '#222222')
    axis.set_xticks(range(7), [str(value) for value in range(-3, 4)])
    axis.set_yticks(range(7), [
        f'{value:+d}  (n={count})' for value, count in zip(range(-3, 4), data['class_support'])
    ])
    axis.set_xlabel('Predicted sentiment')
    axis.set_ylabel('Ground-truth sentiment')
    axis.set_title(f'{dataset}: seven-class confusion matrix\n'
                   f'N={int(data["counts"].sum())}; Acc-7={data["acc7"] * 100:.2f}%')
    figure.colorbar(image, ax=axis, label='Within ground-truth class (%)', shrink=0.85)
    save_figure(figure, output, name, formats=formats)


def draw_corrections(data, output, dataset, averaged=False):
    gains = data['averaged'] if averaged else data['sequential']
    summaries = gain_summary(gains)
    figure, axes = plt.subplots(1, 3, figsize=(15, 4.8), layout='constrained')
    labels = ['b', 'b + support', 'b + conflict', 'Full']
    bars = axes[0].bar(labels, data['mae'], color=['#8c8c8c', COLORS['Support'], COLORS['Conflict'], '#3f6a48'])
    axes[0].bar_label(bars, fmt='%.4f', padding=4, fontsize=9)
    axes[0].set_ylim(0, max(data['mae']) * 1.18)
    axes[0].set_ylabel('Mean absolute error')
    axes[0].set_title('(a) Four prediction combinations')
    axes[0].tick_params(axis='x', labelsize=9)
    bound = max(np.max(np.abs(gains[branch])) for branch in ('Support', 'Conflict'))
    bins = np.linspace(-max(bound, 1e-3), max(bound, 1e-3), 41)
    for branch in ('Support', 'Conflict'):
        axes[1].hist(gains[branch], bins=bins, histtype='step', linewidth=1.7,
                     label=branch, color=COLORS[branch])
    axes[1].axvline(0, color='#555555', linewidth=0.8, linestyle='--')
    axes[1].set_xlabel('Absolute-error reduction (>0 helps)')
    axes[1].set_ylabel('Samples')
    axes[1].set_title('(b) Correction gain distributions')
    axes[1].legend(frameon=False)
    branches = list(gains)
    left = np.zeros(len(branches))
    for field, label, color in (
        ('helpful_fraction', 'Helpful', '#498765'),
        ('unchanged_fraction', 'Unchanged', '#bdbdbd'),
        ('harmful_fraction', 'Harmful', '#c2695d'),
    ):
        widths = np.array([summaries[branch][field] * 100 for branch in branches])
        axes[2].barh(branches, widths, left=left, color=color, label=label, height=0.6)
        for index, width in enumerate(widths):
            if width >= 7:
                axes[2].text(left[index] + width / 2, index, f'{width:.1f}%',
                             ha='center', va='center', fontsize=9)
        left += widths
    axes[2].set_xlim(0, 100)
    axes[2].invert_yaxis()
    axes[2].set_xlabel('Test samples (%)')
    axes[2].set_title('(c) Helpful / unchanged / harmful')
    axes[2].legend(frameon=False, loc='upper center', bbox_to_anchor=(0.5, -0.15), ncol=3, fontsize=8)
    protocol = 'Order-averaged contributions' if averaged else 'Sequential contributions: support first, conflict second'
    figure.suptitle(f'{dataset}: fixed-model correction effects\n{protocol}', fontsize=12)
    name = 'figure3_order_averaged' if averaged else 'figure3_correction_effects'
    save_figure(figure, output, name)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--job', type=Path, required=True)
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    job = args.job.resolve()
    config = json.loads((job / 'effective_config.json').read_text())
    if config['dataset_name'] != 'mosi':
        raise ValueError('This figure set currently supports MOSI only')
    predictions = json.loads((job / 'test_predictions.json').read_text())
    metrics = json.loads((job / 'metrics.json').read_text())
    metadata = json.loads((job / 'checkpoint_metadata.json').read_text())
    data = analyze(predictions)
    if abs(data['mae'][3] - metrics['MAE']) > 5.1e-5 or abs(data['acc7'] - metrics['acc_7']) > 5.1e-5:
        raise ValueError('Computed MAE/Acc7 disagree with saved metrics')
    output = args.output or job / 'paper_figures'
    output.mkdir(parents=True, exist_ok=False)
    plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 10,
                         'pdf.fonttype': 42, 'ps.fonttype': 42,
                         'axes.spines.top': False, 'axes.spines.right': False})
    draw_confusion(data, output, 'CMU-MOSI')
    draw_corrections(data, output, 'CMU-MOSI')
    draw_corrections(data, output, 'CMU-MOSI', averaged=True)
    np.savetxt(output / 'confusion_counts.csv', data['counts'], delimiter=',', fmt='%d',
               header='predicted classes: -3,-2,-1,0,1,2,3; rows: same ground-truth order')
    np.savetxt(output / 'confusion_row_percent.csv', data['normalized'] * 100, delimiter=',', fmt='%.6f',
               header='predicted classes: -3,-2,-1,0,1,2,3; rows: same ground-truth order')
    summary = {
        'job': str(job), 'checkpoint_metadata': metadata, 'sample_count': len(predictions),
        'class_support': data['class_support'].tolist(), 'Acc7': data['acc7'],
        'MAE': dict(zip(('b', 'b+support', 'b+conflict', 'full'), data['mae'].tolist())),
        'sequential': gain_summary(data['sequential']), 'order_averaged': gain_summary(data['averaged']),
        'neutral_gain_tolerance': TOLERANCE,
    }
    (output / 'statistics.json').write_text(json.dumps(summary, indent=2))
    with (output / 'sample_gains.csv').open('w', newline='') as handle:
        writer = csv.writer(handle)
        writer.writerow(['id', 'support_sequential', 'conflict_sequential', 'total',
                         'support_order_averaged', 'conflict_order_averaged'])
        for index, row in enumerate(predictions):
            writer.writerow([row['id'], *(data['sequential'][branch][index] for branch in ('Support', 'Conflict', 'Total')),
                             *(data['averaged'][branch][index] for branch in ('Support', 'Conflict'))])
    (output / 'README.md').write_text(
        '# MOSI paper figures\n\n'
        '- figure2_mosi_confusion.pdf/png: Figure 2 MOSI panel; labels clipped then NumPy-rounded; rows normalized.\n'
        '- figure3_correction_effects.pdf/png: four combinations and sequential support-first/conflict-second gains.\n'
        '- figure3_order_averaged.pdf/png: supplementary gains averaged over both correction orders.\n'
        '- statistics.json, sample_gains.csv and confusion CSVs: measured values and checkpoint provenance.\n\n'
        f'Checkpoint selection: {metadata["selection_metric"]}; epoch: {metadata["epoch"]}.\n'
        'These figures use one fixed checkpoint, not retrained ablation models.\n'
        'Correction contribution does not establish semantic conflict or causal interpretation.\n'
        'MOSEI and Figure 4 temperature sensitivity are not included; no temperature measurements were fabricated.\n'
    )
    print(f'Saved figures to {output}')
    print(json.dumps(summary['MAE'], indent=2))


if __name__ == '__main__':
    main()