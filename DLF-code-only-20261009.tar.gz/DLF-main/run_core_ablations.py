import argparse
import csv
import hashlib
import json
import os
from pathlib import Path
import select
import shutil
import subprocess
import sys
from datetime import datetime


VARIANTS = {
    'unsplit-residual': {
        'unsplit_residual': True,
        'use_conflict_correction': False,
        'ccdr_decorrelation_weight': 0.0,
        'cred_routing_weight': 0.0,
        'ccdr_ranking_weight': 0.0,
        'ccdr_delta_weight': 0.0,
        'cred_effect_weight': 0.0,
        'cred_support_task_weight': 0.0,
    },
    'no-support': {
        'use_support_correction': False,
        'cred_support_task_weight': 0.0,
    },
    'no-conflict': {
        'use_conflict_correction': False,
        'ccdr_ranking_weight': 0.0,
        'ccdr_delta_weight': 0.0,
    },
    'no-language-anchor': {'use_language_anchor': False},
    'full': {},
}

TABLE5_VARIANTS = {
    'full': {},
    'language-only': {
        'active_modalities': [0], 'use_conflict_correction': False,
        'cred_routing_weight': 0.0, 'ccdr_ranking_weight': 0.0,
        'ccdr_delta_weight': 0.0,
    },
    'language-audio': {'active_modalities': [0, 1]},
    'language-vision': {'active_modalities': [0, 2]},
    'no-routing-loss': {'cred_routing_weight': 0.0},
    'no-support-scale-loss': {'cred_support_gate_weight': 0.0},
    'no-directional-loss': {'cred_effect_weight': 0.0},
}


def variant_overrides(name, suite='core'):
    table5 = suite == 'table5'
    return {
        'architecture': 'serial_ccdr',
        'input_level': 'sequence',
        'unsplit_residual': False,
        'use_support_correction': True,
        'use_conflict_correction': True,
        'use_language_anchor': True,
        'active_modalities': [0, 1, 2],
        'enable_support_scale_loss': table5,
        'cred_support_gate_weight': 0.05 if table5 else 0.0,
        'cred_support_gate_min_delta': 1e-4,
        'ablation_name': f'table5-{name}' if table5 else name,
        **(TABLE5_VARIANTS if table5 else VARIANTS)[name],
    }


def write_json(path, value):
    temporary = path.with_suffix('.tmp')
    temporary.write_text(json.dumps(value, indent=2))
    temporary.replace(path)


def parse_args():
    parser = argparse.ArgumentParser(description='Frozen, sequential core ablations')
    parser.add_argument('--suite', choices=['core', 'table5'], default='core')
    parser.add_argument('--datasets', nargs='+', choices=['mosi', 'mosei'], default=['mosi'])
    parser.add_argument('--variants', nargs='+', choices=sorted(set(VARIANTS) | set(TABLE5_VARIANTS)))
    parser.add_argument('--seeds', nargs='+', type=int, default=[1111])
    parser.add_argument('--gpu', type=int, default=0)
    parser.add_argument('--max-epochs', type=int)
    parser.add_argument('--wait-pids', nargs='*', type=int, default=[])
    parser.add_argument('--output', type=Path)
    parser.add_argument('--dry-run', action='store_true')
    parser.add_argument('--worker', type=Path)
    args = parser.parse_args()
    registry = TABLE5_VARIANTS if args.suite == 'table5' else VARIANTS
    args.variants = args.variants or list(registry)
    if any(variant not in registry for variant in args.variants):
        parser.error('Variant does not belong to the selected suite')
    if args.suite == 'table5' and args.datasets != ['mosi']:
        parser.error('Manuscript Table 5 is defined on MOSI only')
    return args


def run_worker(job_path):
    from run import DLF_run

    job = json.loads(job_path.read_text())
    root = job_path.parent
    overrides = job['overrides']
    overrides['test_predictions_path'] = str(root / 'test_predictions.json')
    overrides['checkpoint_metadata_path'] = str(root / 'checkpoint_metadata.json')
    overrides['experiment_seed'] = job['seed']
    results = DLF_run(
        'DLF', job['dataset'], config=overrides,
        config_file=job['config_file'], seeds=[job['seed']],
        gpu_ids=[job['gpu']], num_workers=0,
        model_save_dir=str(root / 'pt'), res_save_dir=str(root / 'result'),
        log_dir=str(root / 'log'), mode='train', is_training=True,
    )
    write_json(root / 'metrics.json', results[0])


def prepare_suite(args):
    project = Path(__file__).resolve().parent
    suite = getattr(args, 'suite', 'core')
    stamp = datetime.now().strftime('%Y%m%d-%H%M%S-%f')
    root = (args.output or project / 'experiments' / f'{suite}-ablations' / stamp).resolve()
    root.mkdir(parents=True, exist_ok=False)
    source = root / 'source'
    source.mkdir()
    for path in project.glob('*.py'):
        shutil.copy2(path, source / path.name)
    for name in ('trains', 'utils', 'tests'):
        shutil.copytree(project / name, source / name,
                        ignore=shutil.ignore_patterns('__pycache__', '*.pyc'))
    config = json.loads((project / 'config/config.json').read_text())
    config['datasetCommonParams']['dataset_root_dir'] = str(
        (project / config['datasetCommonParams']['dataset_root_dir']).resolve()
    )
    config_path = root / 'config.json'
    write_json(config_path, config)
    from config import get_config_regression

    manifest = {
        'created_at': datetime.now().isoformat(),
        'status': 'prepared', 'suite': suite, 'wait_pids': args.wait_pids,
        'source_sha256': {
            str(path.relative_to(source)): hashlib.sha256(path.read_bytes()).hexdigest()
            for path in source.rglob('*.py')
        },
        'notes': [
            ('Table5 enables detached continuous support-scale targets with Smooth L1 weight 0.05, except no-support-scale-loss.'
             if suite == 'table5' else 'Support-scale supervision is disabled in every core variant for compatibility.'),
            'Unsplit uses pooled P+Q and one scaled residual head; route, three-way decorrelation and role-specific losses are disabled.',
            'No-support/no-conflict remove additive corrections, not all corresponding representations.',
            'No-language-anchor replaces nonverbal retrieval with pooled nonverbal conflict and zeros the direct language input to its head.',
            'Full is retrained under the same frozen configuration; old paper scores are not the matched reference.',
            'Only active modalities enter donor attention, pooling, probes and backbone auxiliary supervision.',
            'Language-only has no donors (agreement gate 0.5), cross-modal routing supervision or AV conflict correction.',
            'No-directional-loss removes both support and conflict direction penalties, not only support.',
        ],
        'jobs': [],
    }
    for dataset in args.datasets:
        for seed in args.seeds:
            for variant in args.variants:
                overrides = variant_overrides(variant, suite)
                if args.max_epochs is not None:
                    overrides['max_epochs'] = args.max_epochs
                effective = get_config_regression('DLF', dataset, str(config_path))
                effective.update(overrides)
                if not Path(effective.featurePath).is_file():
                    raise FileNotFoundError(effective.featurePath)
                if effective.transformers != 'deberta' or not effective.use_finetune:
                    raise ValueError('Core ablations require the configured fine-tuned DeBERTa setup')
                job_dir = root / dataset / str(seed) / variant
                job_dir.mkdir(parents=True)
                (job_dir / 'log').mkdir()
                job = {
                    'dataset': dataset, 'seed': seed, 'variant': variant,
                    'gpu': args.gpu, 'config_file': str(config_path),
                    'overrides': overrides,
                }
                write_json(job_dir / 'job.json', job)
                write_json(job_dir / 'effective_config.json', dict(effective))
                manifest['jobs'].append({
                    **job, 'path': str(job_dir), 'status': 'pending',
                })
    write_json(root / 'manifest.json', manifest)
    return root, manifest

def summarize_suite(root, manifest):
    rows = []
    references = {
        (job['dataset'], job['seed']): job['metrics']['MAE']
        for job in manifest['jobs']
        if job['variant'] == 'full' and job['status'] == 'completed'
    }
    for job in manifest['jobs']:
        if job['status'] != 'completed':
            continue
        metadata = json.loads((Path(job['path']) / 'checkpoint_metadata.json').read_text())
        reference = references.get((job['dataset'], job['seed']))
        rows.append({
            'dataset': job['dataset'], 'seed': job['seed'], 'variant': job['variant'],
            'best_epoch': metadata['epoch'], **job['metrics'],
            'MAE_delta_vs_full': job['metrics']['MAE'] - reference if reference is not None else '',
        })
    if not rows:
        return
    with (root / 'summary.csv').open('w', newline='') as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    lines = ['# Table 5' if manifest.get('suite') == 'table5' else '# Core ablations', '',
             'Validation-selected checkpoints; test Acc2/F1 exclude zero labels. Accuracy/F1 shown as percentages.', '',
             '| Dataset | Seed | Variant | Epoch | Acc7 | Acc2 | F1 | MAE | Corr | MAE delta |',
             '| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |']
    for row in rows:
        delta = row['MAE_delta_vs_full']
        delta_text = f'{delta:+.4f}' if delta != '' else ''
        lines.append(
            f"| {row['dataset']} | {row['seed']} | {row['variant']} | {row['best_epoch']} | "
            f"{row['acc_7'] * 100:.2f} | {row['acc_2'] * 100:.2f} | "
            f"{row['F1_score'] * 100:.2f} | {row['MAE']:.4f} | {row['Corr']:.4f} | {delta_text} |"
        )
    lines.extend(['', 'Single-seed results do not establish statistical significance.'])
    (root / 'summary.md').write_text('\n'.join(lines) + '\n')


def run_suite(args):
    root, manifest = prepare_suite(args)
    print(f'Suite: {root}', flush=True)
    if args.dry_run:
        return
    for process_id in args.wait_pids:
        try:
            descriptor = os.pidfd_open(process_id)
        except ProcessLookupError:
            continue
        manifest['status'] = 'waiting'
        write_json(root / 'manifest.json', manifest)
        print(f'Waiting for existing PID {process_id}', flush=True)
        try:
            select.select([descriptor], [], [])
        finally:
            os.close(descriptor)
    manifest['status'] = 'running'
    try:
        for job in manifest['jobs']:
            job_dir = Path(job['path'])
            job['status'] = 'running'
            job['started_at'] = datetime.now().isoformat()
            write_json(root / 'manifest.json', manifest)
            print(f"Starting {job['dataset']} {job['variant']} seed={job['seed']}", flush=True)
            with (job_dir / 'console.log').open('w') as console:
                completed = subprocess.run(
                    [sys.executable, '-u', str(root / 'source/run_core_ablations.py'),
                     '--worker', str(job_dir / 'job.json')],
                    cwd=Path(__file__).resolve().parent,
                    stdout=console, stderr=subprocess.STDOUT,
                )
            job['exit_code'] = completed.returncode
            job['finished_at'] = datetime.now().isoformat()
            job['status'] = 'completed' if completed.returncode == 0 else 'failed'
            if completed.returncode == 0:
                job['metrics'] = json.loads((job_dir / 'metrics.json').read_text())
            write_json(root / 'manifest.json', manifest)
            summarize_suite(root, manifest)
            if completed.returncode != 0:
                raise RuntimeError(f"Job failed; see {job_dir / 'console.log'}")
        manifest['status'] = 'completed'
    except BaseException:
        manifest['status'] = 'stopped'
        raise
    finally:
        write_json(root / 'manifest.json', manifest)


if __name__ == '__main__':
    arguments = parse_args()
    if arguments.worker:
        run_worker(arguments.worker)
    else:
        run_suite(arguments)