"""Prepare auditable qualitative candidates from one model's saved predictions."""

import argparse
import csv
import json
import math
import pickle
from pathlib import Path


def build_rows(predictions, split):
    identities = [str(identity) for identity in split['id']]
    if len(set(identities)) != len(identities):
        raise ValueError('Duplicate dataset IDs')
    samples = dict(zip(identities, zip(split['raw_text'], split['regression_labels'])))
    seen = set()
    rows = []
    for prediction in predictions:
        identity = prediction['id']
        if identity in seen:
            raise ValueError(f'Duplicate prediction ID: {identity}')
        seen.add(identity)
        transcript, label = samples[identity]
        target = float(prediction['target'])
        baseline = float(prediction['consensus_logit'])
        support = float(prediction['support_delta'])
        conflict = float(prediction['conflict_delta'])
        final = float(prediction['output_logit'])
        if not all(math.isfinite(value) for value in (target, baseline, support, conflict, final)):
            raise ValueError(f'Non-finite output: {identity}')
        if not math.isclose(target, float(label), abs_tol=1e-5):
            raise ValueError(f'Label mismatch: {identity}')
        if not math.isclose(final, baseline + support + conflict, abs_tol=1e-5):
            raise ValueError(f'Additive output mismatch: {identity}')
        error_baseline = abs(baseline - target)
        error_support = abs(baseline + support - target)
        error_conflict = abs(baseline + conflict - target)
        error_final = abs(final - target)
        support_gain = error_baseline - error_support
        conflict_gain = error_support - error_final
        support_average = 0.5 * (support_gain + error_conflict - error_final)
        conflict_average = 0.5 * (error_baseline - error_conflict + conflict_gain)
        rows.append({
            'id': identity, 'transcript': str(transcript), 'target': target,
            'consensus': baseline, 'support_delta': support, 'conflict_delta': conflict,
            'prediction': final, 'error_consensus': error_baseline,
            'error_support_only': error_support, 'error_conflict_only': error_conflict,
            'error_final': error_final, 'support_gain': support_gain,
            'conflict_gain': conflict_gain, 'total_gain': error_baseline - error_final,
            'support_order_averaged_gain': support_average,
            'conflict_order_averaged_gain': conflict_average,
            'acoustic_cues': 'Pending original-clip review',
            'visual_cues': 'Pending original-clip review',
        })
    if seen != set(identities):
        raise ValueError('Predictions must cover the complete split')
    return rows


def select_cases(rows, count=5):
    if count < 1:
        raise ValueError('Candidate count must be positive')
    definitions = (
        ('Helpful support', 'support_order_averaged_gain',
         lambda row: row['support_gain'] > 1e-6
         and row['support_order_averaged_gain'] > 1e-6 and row['total_gain'] > 1e-6, True),
        ('Helpful conflict', 'conflict_order_averaged_gain',
         lambda row: row['conflict_gain'] > 1e-6
         and row['conflict_order_averaged_gain'] > 1e-6 and row['total_gain'] > 1e-6, True),
        ('Harmful correction', 'total_gain', lambda row: row['total_gain'] < -1e-6, False),
    )
    candidates, selected, used = {}, [], set()
    for category, metric, eligible, reverse in definitions:
        ranked = sorted((row for row in rows if eligible(row)),
                        key=lambda row: (-row[metric] if reverse else row[metric], row['id']))
        candidates[category] = ranked[:count]
        available = [row for row in ranked if row['id'] not in used]
        if not available:
            raise ValueError(f'No distinct measured case for {category}')
        chosen = available[0]
        used.add(chosen['id'])
        selected.append({'category': category, **chosen})
    return candidates, selected


def write_outputs(output, rows, candidates, selected, provenance):
    output.mkdir(parents=True, exist_ok=False)
    with (output / 'all_samples.csv').open('w', newline='', encoding='utf-8') as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    payload = {'provenance': provenance, 'candidates': candidates, 'selected': selected}
    (output / 'cases.json').write_text(json.dumps(payload, indent=2), encoding='utf-8')
    lines = [
        '# Table 6: measured qualitative candidates', '',
        'One validation-selected model; all values come from its saved test predictions.',
        'These are gain-ranked illustrative cases, not representative performance evidence.',
        'Acoustic/visual cues and final semantic case selection require original-clip review.', '',
        '| Category | Sample ID | Transcript | y | b | delta_s | delta_c | prediction |',
        '| --- | --- | --- | --- | --- | --- | --- | --- |',
    ]
    for row in selected:
        transcript = row['transcript'].replace('|', '\\|').replace('\n', ' ')
        lines.append(
            f"| {row['category']} | {row['id']} | {transcript} | {row['target']:.4f} | "
            f"{row['consensus']:.4f} | {row['support_delta']:+.4f} | "
            f"{row['conflict_delta']:+.4f} | {row['prediction']:.4f} |"
        )
    lines.extend(['', '## Error changes', '',
                  '| Category | Baseline error | Final error | Support gain | Conflict gain | Total gain |',
                  '| --- | --- | --- | --- | --- | --- |'])
    for row in selected:
        lines.append(
            f"| {row['category']} | {row['error_consensus']:.4f} | {row['error_final']:.4f} | "
            f"{row['support_gain']:+.4f} | {row['conflict_gain']:+.4f} | {row['total_gain']:+.4f} |"
        )
    lines.extend([
        '', 'Positive gain means lower absolute error.',
        'Support gain = |b-y| - |b+delta_s-y|.',
        'Conflict gain = |b+delta_s-y| - |prediction-y|.',
        'Ranking helpful cases uses each branch\'s gain averaged over both correction orders,',
        'with positive sequential gain and positive total gain required.',
        'Harmful cases are ranked by the most negative total gain. Ties use sample ID.',
        'The three selected cases have distinct IDs; complete candidate lists are in cases.json.',
        '', '## Provenance', '',
    ])
    lines.extend(f'- {key}: {value}' for key, value in provenance.items())
    (output / 'table6.md').write_text('\n'.join(lines) + '\n', encoding='utf-8')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--job', type=Path, required=True)
    parser.add_argument('--output', type=Path)
    parser.add_argument('--candidates', type=int, default=5)
    args = parser.parse_args()
    job = args.job.resolve()
    config = json.loads((job / 'effective_config.json').read_text())
    metadata = json.loads((job / 'checkpoint_metadata.json').read_text())
    predictions_path = job / 'test_predictions.json'
    predictions = json.loads(predictions_path.read_text())
    with Path(config['featurePath']).open('rb') as handle:
        split = pickle.load(handle)['test']
    rows = build_rows(predictions, split)
    metrics = json.loads((job / 'metrics.json').read_text())
    measured_mae = sum(row['error_final'] for row in rows) / len(rows)
    if not math.isclose(measured_mae, metrics['MAE'], abs_tol=5.1e-5):
        raise ValueError('Saved test predictions disagree with reported MAE')
    candidates, selected = select_cases(rows, args.candidates)
    provenance = {
        'job': str(job), 'predictions': str(predictions_path),
        'feature_file': config['featurePath'], 'split': 'test',
        'sample_count': len(rows), 'checkpoint': metadata['checkpoint'],
        'best_epoch': metadata['epoch'], 'seed': metadata['seed'],
        'selection_metric': metadata['selection_metric'], 'test_MAE': measured_mae,
        'clip_review': 'Pending; no acoustic or visual descriptions inferred from features',
    }
    output = args.output or job / 'table6'
    write_outputs(output, rows, candidates, selected, provenance)
    print(f'Saved {output / "table6.md"}')
    for row in selected:
        print(row['category'], row['id'], f"total gain={row['total_gain']:+.4f}")


if __name__ == '__main__':
    main()